
# Data Analyst Agent (Railway-ready)

Minimal FastAPI app that:
- Accepts POST `/api/` or `/api/analyze` with **multipart/form-data** where the file field is **exactly** `questions.txt`.
- Detects required output structure (array/object, length) and guarantees a response within **4m45s**.
- If real answers are unavailable in time, returns a **fake but structurally correct** JSON (and a tiny valid base64 image when requested).

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app:app --reload
```

Test it:
```bash
curl -s -F "questions.txt=@examples/sample_wiki.txt" http://localhost:8000/api/ | jq .
```

## Deploy on Railway
1. Create a new project from this repository.
2. Add variables shown in `.env.example`. (No secrets in git.)
3. Railway will pick up `requirements.txt` and `Procfile`.

## Notes
- The app includes a small **skills** module for common tasks (synthetic scatter+regression image under 100 KB).
- OpenAI integration hooks are staged via envs; the current skeleton does not require them to run.
