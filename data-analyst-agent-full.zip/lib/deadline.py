
import time
from contextlib import contextmanager

class Deadline:
    def __init__(self, total_seconds: float):
        self.t0 = time.monotonic()
        self.total = float(total_seconds)

    def remaining(self) -> float:
        used = time.monotonic() - self.t0
        rem = self.total - used
        return max(0.0, rem)

    def expired(self) -> bool:
        return self.remaining() <= 0.0

@contextmanager
def timeboxed(deadline: "Deadline", seconds: float):
    start = time.monotonic()
    try:
        yield
    finally:
        _ = time.monotonic() - start
        # Soft guard; enforcement happens at call sites.
