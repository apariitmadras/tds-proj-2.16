
import re
from typing import Dict, Any, List

def detect_output_schema(prompt: str) -> Dict[str, Any]:
    p = prompt.strip()

    # JSON object?
    if re.search(r"\bJSON\s+object\b", p, re.I):
        keys: List[str] = re.findall(r"^\s*-\s*([A-Za-z0-9_]+)\s*:", p, re.M)
        if not keys:
            keys = ["answer"]
        return {"type": "object", "keys": keys}

    # Array type
    item_type = "string"
    if re.search(r"array\s+of\s+strings", p, re.I):
        item_type = "string"
    elif re.search(r"array\s+of\s+numbers", p, re.I):
        item_type = "number"

    # Count questions like "1.", "2.", ...
    numbers = re.findall(r"^\s*\d+\.\s", p, re.M)
    length = len(numbers) if numbers else 1

    m = re.search(r"exactly\s+(\d+)\s+item", p, re.I)
    if m:
        length = int(m.group(1))

    return {"type": "array", "item_type": item_type, "length": max(1, length)}

def wants_base64_image(prompt: str) -> bool:
    return bool(re.search(r"base-?64\s+encoded\s+data\s+URI", prompt, re.I))

def image_mime_from_prompt(prompt: str) -> str:
    if re.search(r"\bwebp\b", prompt, re.I):
        return "image/webp"
    if re.search(r"\bjpg|jpeg\b", prompt, re.I):
        return "image/jpeg"
    return "image/png"
