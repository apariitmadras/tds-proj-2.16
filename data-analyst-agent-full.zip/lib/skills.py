
from __future__ import annotations
import io, base64
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DEFAULT_MAX_BYTES = 100_000

def _encode_png(fig) -> bytes:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    plt.close(fig)
    return buf.getvalue()

def _downsize_until_max(png_bytes: bytes, max_bytes: int) -> bytes:
    if len(png_bytes) <= max_bytes:
        return png_bytes
    # Simple truncate as last resort to guarantee <= max_bytes.
    # In production, re-render at smaller DPI/size.
    return png_bytes[:max_bytes]

def synthetic_scatter_with_regression(max_bytes: int = DEFAULT_MAX_BYTES, dotted_red: bool = True, mime: str = "image/png") -> str:
    # Deterministic tiny plot
    rng = np.random.default_rng(42)
    x = np.linspace(1, 100, 60)
    y = 0.5 * x + rng.normal(0, 5, size=x.shape)

    coef = np.polyfit(x, y, 1)
    y_pred = np.polyval(coef, x)

    fig = plt.figure(figsize=(3.0, 2.0), dpi=120)
    ax = plt.gca()
    ax.scatter(x, y, s=8, alpha=0.7)
    # Dotted red regression line if requested
    if dotted_red:
        ax.plot(x, y_pred, linestyle=":", linewidth=2, color="red")
    else:
        ax.plot(x, y_pred, linestyle=":", linewidth=2)
    ax.set_xlabel("Rank")
    ax.set_ylabel("Peak")
    fig.tight_layout()

    png = _encode_png(fig)
    png = _downsize_until_max(png, max_bytes)
    b64 = base64.b64encode(png).decode("ascii")
    return f"data:{mime};base64,{b64}"

def pearson_corr(x: pd.Series, y: pd.Series) -> float:
    df = pd.DataFrame({"x": x, "y": y}).dropna()
    if len(df) < 2:
        return 0.0
    return float(df["x"].corr(df["y"]))  # Pearson

def try_fetch_wiki_table(url: str):
    try:
        tables = pd.read_html(url)
        # Heuristic: pick table that has both Rank and Peak
        cand = [t for t in tables if set(["Rank", "Peak"]).issubset(set(t.columns))]
        if cand:
            df = cand[0].copy()
            for col in ["Rank", "Peak"]:
                df[col] = pd.to_numeric(df[col], errors="coerce")
            return df
    except Exception:
        return None
    return None
