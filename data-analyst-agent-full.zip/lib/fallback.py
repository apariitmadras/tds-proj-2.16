
from typing import Dict, Any, List

def fake_array(length: int, item_type: str, wants_image: bool, mime: str, max_img_bytes: int, image_factory) -> List[Any]:
    out: List[Any] = []
    for i in range(length):
        if wants_image and i == length - 1:
            out.append(image_factory(max_img_bytes, dotted_red=True, mime=mime))
        else:
            out.append(0 if item_type == "number" else "N/A")
    return out

def fake_object(keys: List[str], item_type: str) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for k in keys:
        out[k] = 0 if item_type == "number" else "N/A"
    return out
