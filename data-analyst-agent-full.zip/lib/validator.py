
import json
from typing import Any

def ensure_json_only(data: Any) -> str:
    # Compact JSON string, no trailing newline
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))
